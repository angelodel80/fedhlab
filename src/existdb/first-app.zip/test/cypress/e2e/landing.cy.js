/* global cy */
describe('The landing page', function () {
  it('should load ', function () {
    cy.visit('/exist/apps/first/index.html')
      .get('.alert')
      .contains('app.xqm')
  })

})
